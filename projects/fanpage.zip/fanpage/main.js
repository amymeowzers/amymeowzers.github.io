function myFunction(x) {
  x.classList.toggle("fa-thumbs-down");
}